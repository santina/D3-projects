Mutation View
==========

My attempt to turn Variant View into a D3 thing that can be added to elastic search 
and ofc look much prettier 

AJAX:  Web applications can send data to and retrieve from a server asynchronously 
(in the background) without interfering with the display and behavior of the existing page